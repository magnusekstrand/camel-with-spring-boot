package com.in28minutes.microservices.camelmicroservicea;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelMicroserviceAApplicationTests {

	@Test
	void contextLoads() {
	}

}
